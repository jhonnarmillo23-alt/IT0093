//
//  ViewController.swift
//  CampusCompanion
//
//  Created by ARMILLO, JHONN GABRIELL on 9/19/26.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel.text = "Campus Companion"
    }

    @IBAction func didTapGetStarted(_ sender: UIButton) {
        subtitleLabel.text = "Let's get started!"
    }
}
