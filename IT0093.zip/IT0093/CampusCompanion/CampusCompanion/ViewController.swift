//
//  ViewController.swift
//  CampusCompanion
//
//  Created by ARMILLO, JHONN GABRIELL on 9/19/26.
//

import UIKit

class ViewController: UIViewController {

    // Existing outlet
    @IBOutlet weak var subtitleLabel: UILabel!

    // Part 2 outlets
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var notifySwitch: UISwitch!
    @IBOutlet weak var roleSegmentedControl: UISegmentedControl!

    // Part 3 outlets
    @IBOutlet weak var eventDatePicker: UIDatePicker!
    @IBOutlet weak var guestsStepper: UIStepper!

    override func viewDidLoad() {
        super.viewDidLoad()
        if subtitleLabel.text?.isEmpty ?? true {
            subtitleLabel.text = "Your campus life, simplified."
        }
    }

    // Existing button action
    @IBAction func getStartedTapped(_ sender: UIButton) {
        subtitleLabel.text = "Let's get started!"
    }

    // New: Explore button action (Step 7 + Step 6a)
    @IBAction func exploreButtonTapped(_ sender: UIButton) {
        nameTextField.resignFirstResponder() // dismiss keyboard
        performSegue(withIdentifier: "ShowDetailSegue", sender: self)
    }

    // Step 6b: Pass captured values to DetailViewController
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowDetailSegue",
              let destination = segue.destination as? DetailViewController else {
            return
        }

        // Name with default fallback
        let enteredName = nameTextField.text ?? ""
        destination.studentName = enteredName.isEmpty ? "Student" : enteredName

        // Notify switch
        destination.notificationsEnabled = notifySwitch.isOn

        // Role from segmented control
        destination.selectedRole = roleSegmentedControl.selectedSegmentIndex == 0 ? "Student" : "Faculty"

        // Part 3: Date picker and guests
        destination.preferredEventDate = eventDatePicker.date
        destination.numberOfGuests = Int(guestsStepper.value)
    }
}
